# Sol Solar Solutions Landing Page

This is a single-page static site for **Sol Solar Solutions LLC**.

## Files
- `index.html` — the complete landing page (solar, Supreme Wealth Vehicle recruiting, Pudu Robotics, lead form, and logo video).

## How to deploy with GitHub + Vercel

1. Create a new GitHub repository (public or private).
2. Upload this `index.html` file to the root of the repo.
3. Go to [vercel.com](https://vercel.com) and click **New Project**.
4. Import the GitHub repository you just created.
5. When Vercel asks for settings:
   - Framework: **Other** or **Static**
   - Build Command: **(leave empty)**
   - Output Directory: **.**
6. Click **Deploy**. Vercel will give you a live URL like `https://your-project-name.vercel.app`.

You can later add your own domain in Vercel's dashboard if you want a custom URL.
